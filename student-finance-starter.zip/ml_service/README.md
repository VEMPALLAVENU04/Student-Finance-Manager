ML service stub. Run `uvicorn main:app --reload --port 8100`.
