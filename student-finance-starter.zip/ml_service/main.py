from fastapi import FastAPI
from pydantic import BaseModel
from typing import Optional
app = FastAPI(title='ML Service - categorization stub')

class PredictRequest(BaseModel):
    merchant: Optional[str] = None
    description: Optional[str] = None
    amount: Optional[float] = None

@app.post('/predict')
def predict(req: PredictRequest):
    # Placeholder: very naive rule-based categorization
    text = ' '.join(filter(None, [req.merchant or '', req.description or ''])).lower()
    if 'uber' in text or 'ola' in text or 'taxi' in text:
        cat = 'Transport'
    elif 'cafe' in text or 'restaurant' in text or 'zomato' in text:
        cat = 'Food'
    elif req.amount and abs(req.amount) > 10000:
        cat = 'Rent'
    else:
        cat = 'Misc'
    return {'category': cat, 'confidence': 0.6}
