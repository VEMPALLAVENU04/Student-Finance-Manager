export default function Home() {
  return (
    <main style={{padding:24, fontFamily:'Inter, system-ui, sans-serif'}}>
      <h1>Student Finance Manager — Frontend (skeleton)</h1>
      <p>This is a starter Next.js app. Implement UI and connect to the backend API at <code>/api</code>.</p>
    </main>
  )
}
