Next.js + Tailwind starter. Run `npm install` then `npm run dev`.
