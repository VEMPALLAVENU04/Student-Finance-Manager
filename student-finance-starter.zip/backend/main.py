from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List, Optional
from datetime import date

app = FastAPI(title='Student Finance Manager - Backend (skeleton)')

class UserCreate(BaseModel):
    email: str
    password: str

class TransactionIn(BaseModel):
    date: date
    amount: float
    merchant: Optional[str] = None
    description: Optional[str] = None

# Simple in-memory stores (replace with DB)
USERS = {}
TRANSACTIONS = {}

@app.post('/auth/signup')
def signup(u: UserCreate):
    if u.email in USERS:
        raise HTTPException(status_code=400, detail='user exists')
    USERS[u.email] = {'email': u.email, 'password': u.password}
    return {'ok': True, 'email': u.email}

@app.post('/transactions')
def add_transaction(tx: TransactionIn):
    tid = len(TRANSACTIONS) + 1
    TRANSACTIONS[tid] = tx.dict()
    TRANSACTIONS[tid]['id'] = tid
    return TRANSACTIONS[tid]

@app.get('/transactions', response_model=List[TransactionIn])
def list_transactions():
    return list(TRANSACTIONS.values())
