FastAPI backend skeleton. Run `uvicorn main:app --reload --port 8000` after installing requirements.
