# Student Finance Manager — Starter Project

This starter contains three services in a monorepo:
- `frontend/` — Next.js + Tailwind starter (skeleton only)
- `backend/`  — FastAPI backend skeleton with auth & transaction endpoints
- `ml_service/` — Small FastAPI ML service stub for transaction categorization
- `docker-compose.yml` — development compose to run all services
- `docker/` — Dockerfiles for services

## How to use
Each service has its own README with startup instructions. This repo is a skeleton — fill in implementation details as required.
